(self["webpackChunkspf_lookup"] = self["webpackChunkspf_lookup"] || []).push([["node_child_process"],{

/***/ "node:child_process":
/*!**************************!*\
  !*** node:child_process ***!
  \**************************/
/***/ (() => {

throw new Error("Module build failed: UnhandledSchemeError: Reading from \"node:child_process\" is not handled by plugins (Unhandled scheme).\nWebpack supports \"data:\" and \"file:\" URIs by default.\nYou may need an additional plugin to handle \"node:\" URIs.\n    at /mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/NormalModule.js:918:25\n    at Hook.eval [as callAsync] (eval at create (/mnt/data/anton/projects/spf_lookup/node_modules/tapable/lib/HookCodeFactory.js:33:10), <anonymous>:6:1)\n    at Object.processResource (/mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/NormalModule.js:915:8)\n    at processResource (/mnt/data/anton/projects/spf_lookup/node_modules/loader-runner/lib/LoaderRunner.js:220:11)\n    at iteratePitchingLoaders (/mnt/data/anton/projects/spf_lookup/node_modules/loader-runner/lib/LoaderRunner.js:171:10)\n    at runLoaders (/mnt/data/anton/projects/spf_lookup/node_modules/loader-runner/lib/LoaderRunner.js:398:2)\n    at NormalModule._doBuild (/mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/NormalModule.js:905:3)\n    at NormalModule.build (/mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/NormalModule.js:1081:15)\n    at /mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/Compilation.js:1400:12\n    at NormalModule.needBuild (/mnt/data/anton/projects/spf_lookup/node_modules/webpack/lib/NormalModule.js:1407:32)");

/***/ })

}]);